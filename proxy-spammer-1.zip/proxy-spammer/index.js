// Подключаю нужные библиотеки
// Установить ты их можешь написав 'npm i'
const axiosreq = require('axios')
const HttpsProxyAgent = require("https-proxy-agent");
const fs = require('fs');
const levelstring = fs.readFileSync("levelstring.txt", "utf-8");
const proxy_list = fs.readFileSync("proxy-list.txt", "utf-8").split("\n");
const config = require('./config');
const url = config.url;
const debug_failed_proxy = config.debug_failed_proxy;
const debug_started_proxy = config.debug_started_proxy;
const negative_statistics = config.negative_statistics;

// Нужные мне функции
function generate(length = 10) {
    var result = '';
    var characters = 'abcdefghijklmnopqrstuvwxyz0123456789';
    var charactersLength = characters.length;
    for (var i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() *
            charactersLength));
    }
    return result;
}

function random(min, max) {
    return Math.floor(
        Math.random() * (max - min) + min
    )
}


let i = 0;
begin();

function begin() {
    if (i >= proxy_list.length) {
        console.log("\nInfo | Proxy ended");
        return;
    }
    let userName = generate(10);
    let password = "JustAPassword.";
    let email = generate(6) + "@gmail.com";
    registerAccount(userName, password, email, proxy_list[i]);
    i++;
    setTimeout(begin, 50);
}

return;
registerAccount(userName, password, email, "45.12.30.144:80");

function registerAccount(userName, password, email, proxy) {
    if (debug_started_proxy) console.log("\nInfo | Начинаем спам с " + proxy);
    let proxy_host = proxy.split(":")[0];
    let proxy_port = proxy.split(":")[1];
    let httpsAgent = new HttpsProxyAgent({ host: proxy_host, port: proxy_port })
    let axios = axiosreq.create({ httpsAgent });

    // Генерирую тело запрос
    let params = new URLSearchParams()
    params.append('userName', userName);
    params.append('password', password);
    params.append('email', email);
    params.append('secret', "Wmfv3899gc9");

    // Параметры запроса
    const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-agent': ' '
            }
        }
        // Запрос
    axios.post(url + "/accounts/registerGJAccount.php", params, config)
        .then((result) => {
            if (result.data == "1") {
                console.log("\nInfo | Аккаунт создан");
                loginAccount(userName, password, proxy);
            } else {
                if (debug_failed_proxy) {
                    let res;
                    if (result.data.length > 10) {
                        res = "Слишком большой ответ";
                    } else {
                        res = result.data;
                    }
                    console.log("\nInfo | Не удалось произвести регистрацию через " + proxy + " | Сервер вернул ответ: " + res)
                }
            }
        })
        .catch((err) => {
            if (debug_failed_proxy) console.log("\nInfo | Не удалось произвести регистрацию через " + proxy);
        })
}

function loginAccount(userName, password, proxy) {
    let proxy_host = proxy.split(":")[0];
    let proxy_port = proxy.split(":")[1];
    let httpsAgent = new HttpsProxyAgent({ host: proxy_host, port: proxy_port })
    let axios = axiosreq.create({ httpsAgent });

    // Генерирую тело запрос
    let params = new URLSearchParams()
    params.append('userName', userName);
    params.append('password', password);
    params.append('udid', generate(30));
    params.append('secret', "Wmfv3899gc9");

    // Параметры запроса
    const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-agent': ' '
            }
        }
        // Запрос
    axios.post(url + "/accounts/loginGJAccount.php", params, config)
        .then((result) => {
            if (result.data.includes(",")) {
                let accountID, userID;
                accountID = result.data.split(",")[0];
                userID = result.data.split(",")[1];
                console.log("\nInfo | Я вошёл в аккаунт! ID: " + accountID + ", userID: " + userID);
                updateUserScore(userName, accountID, userID, proxy);
            } else {
                if (debug_failed_proxy) {
                    let res;
                    if (result.data.length > 10) res = "Слишком большой ответ";
                    else res = result.data;
                    console.log("\nInfo | Не удалось произвести вход через " + proxy + " | Сервер вернул ответ: " + res)
                }
            }
        })
        .catch((err) => {
            if (debug_failed_proxy) console.log("\nInfo | Не удалось произвести вход через " + proxy);
            console.log(err);
        })
}

function updateUserScore(userName, accountID, userID, proxy) {
    let proxy_host = proxy.split(":")[0];
    let proxy_port = proxy.split(":")[1];
    let httpsAgent = new HttpsProxyAgent({ host: proxy_host, port: proxy_port })
    let axios = axiosreq.create({ httpsAgent });

    // Генерирую тело запрос
    let params = new URLSearchParams()
    params.append('gameVersion', '21');
    params.append('binaryVersion', '35');
    params.append('gdw', '0');
    params.append('accountID', accountID);
    params.append('gjp', 'eUJGRndjVkZBQVxFURw=');
    params.append('userName', userName);
    params.append('stars', random(100, 10000));
    if (negative_statistics) params.append('demons', random(-100000, 1000));
    else params.append('demons', random(100, 10000));
    if (negative_statistics) params.append('diamonds', random(-100000, 1000));
    else params.append('diamonds', random(100, 10000));
    params.append('icon', random(1, 142));
    params.append('color1', random(1, 40));
    params.append('color2', random(1, 40));
    params.append('iconType', random(1, 8));
    if (negative_statistics) params.append('coins', random(-100000, 1000));
    else params.append('coins', random(100, 10000));
    if (negative_statistics) params.append('userCoins', random(-100000, 1000));
    else params.append('userCoins', random(100, 10000));
    params.append('special', '0');
    if (negative_statistics) params.append('userCoins', random(-100000, 1000));
    else params.append('userCoins', random(100, 10000));
    params.append('gameVersion', '21');
    params.append('secret', "Wmfv3899gc9");
    params.append('accIcon', random(1, 8));
    params.append('accShip', random(1, 30));
    params.append('accBall', random(1, 30));
    params.append('accBird', random(1, 30));
    params.append('accDart', random(1, 30));
    params.append('accRobot', random(1, 30));
    params.append('accGlow', random(0, 1));
    params.append('accSpider', random(1, 30));
    params.append('accExplosion', random(1, 5));

    // Параметры запроса
    const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-agent': ' '
            }
        }
        // Запрос
    axios.post(url + "/updateGJUserScore22.php", params, config)
        .then((result) => {
            if (result.data == userID) {
                console.log("\nInfo | Статистика накручена");
                uploadLevel(userName, accountID, userID, proxy);
            } else {
                if (debug_failed_proxy) {
                    let res;
                    if (result.data.length > 10) res = "Слишком большой ответ";
                    else res = result.data;
                    console.log("\nInfo | Не удалось накрутить статистику через " + proxy + " | Сервер вернул ответ: " + res)
                }
            }
        })
        .catch((err) => {
            if (debug_failed_proxy) console.log("\nInfo | Не удалось накрутить статистику через " + proxy);
        })
}

function uploadLevel(userName, accountID, userID, proxy) {
    let proxy_host = proxy.split(":")[0];
    let proxy_port = proxy.split(":")[1];
    let httpsAgent = new HttpsProxyAgent({ host: proxy_host, port: proxy_port })
    let axios = axiosreq.create({ httpsAgent });
    // Генерирую тело запрос
    let params = new URLSearchParams()
    params.append('gameVersion', '21');
    params.append('binaryVersion', '35');
    params.append('gdw', '0');
    params.append('accountID', accountID);
    params.append('userName', userName);
    params.append('gjp', 'eUJGRndjVkZBQVxFURw=');
    params.append('levelName', generate(16));
    params.append('levelDesc', 'asd');
    params.append('levelVersion', 1);
    params.append('levelLength', random(1, 4));
    params.append('levelString', levelstring);
    params.append('audioTrack', 0);
    params.append('auto', 0);
    params.append('original', 0);
    params.append('twoPlayer', 0);
    params.append('songID', 0);
    params.append('objects', 0);
    params.append('coins', 0);
    params.append('requestedStars', random(69, 666));
    params.append('unlisted', 0);
    params.append('ldm', 0);
    params.append('extraString', '0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0_0');
    params.append('secret', 'Wmfd2893gb7');

    // Параметры запроса
    const config = {
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'User-agent': ' '
            }
        }
        // Запрос
    axios.post(url + "/uploadGJLevel21.php", params, config)
        .then((result) => {
            if (result.data > 1) {
                let data = fs.readFileSync("working-proxy.txt", 'utf-8');
                fs.writeFileSync("working-proxy.txt", data + "\n" + proxy, "utf-8");
                console.log("\nInfo | Уровень опубликован");
            } else {
                let data = fs.readFileSync("working-proxy.txt", 'utf-8');
                fs.writeFileSync("working-proxy.txt", data + "\n" + proxy, "utf-8");
                if (debug_failed_proxy) {
                    let res;
                    if (result.data.length > 10) res = "Слишком большой ответ";
                    else res = result.data;
                    console.log("\n\nInfo | Не удалось опубликовать уровень через " + proxy + " | Сервер вернул ответ: " + res)
                }
            }
        })
        .catch((err) => {
            if (debug_failed_proxy) console.log("\nInfo | Не удалось опубликовать уровень через " + proxy);
            console.log(err);
        })
}